export class Task {
    id: number;
    num_of_scripts: string;
    status: string;
  }
  