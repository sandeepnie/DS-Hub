﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule }    from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

// used to create fake backend
import { fakeBackendProvider } from './_helpers';

import { AppComponent }  from './app.component';
import { routing }        from './app.routing';

import { AlertComponent } from './_directives';
import { AuthGuard } from './_guards';
import { JwtInterceptor, ErrorInterceptor } from './_helpers';
import { AlertService, AuthenticationService, UserService, UndialService } from './_services';
import { HomeComponent } from './home';
import { LoginComponent } from './login';
import { ExcelService } from './excel.service';

// import { AngularFileUploaderModule } from "angular-file-uploader";
import { SidebarModule } from 'ng-sidebar';
import { AgGridModule } from 'ag-grid-angular';
import { NgxSpinnerModule } from 'ngx-spinner';;
import { FeaturesComponent } from './features/features.component';
import {AgWordCloudModule} from 'angular4-word-cloud';


@NgModule({
    imports: [
        BrowserModule,
        // AngularFileUploaderModule,
        ReactiveFormsModule,
        HttpClientModule,
        NgxSpinnerModule,
        routing,
        FormsModule,
        SidebarModule.forRoot(),
        AgGridModule.withComponents([]),
        AgWordCloudModule.forRoot()
    ],
    declarations: [
        AppComponent,
        AlertComponent,
        HomeComponent,
        LoginComponent,
        FeaturesComponent ],
    providers: [
        AuthGuard,
        AlertService,
        AuthenticationService,
        UserService,
        UndialService,
        { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
        { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
        ExcelService
        // provider used to create fake backend
        // fakeBackendProvider
    ],
    bootstrap: [AppComponent]
})

export class AppModule { }
