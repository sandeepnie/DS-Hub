﻿import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home'; 
import { LoginComponent } from './login';
import { FeaturesComponent } from './features/features.component';
import { AuthGuard } from './_guards';

const appRoutes: Routes = [   
    { path: '', component: HomeComponent, canActivate: [AuthGuard] }, 
    { path: 'login', component: LoginComponent },
    {path:'features', component: FeaturesComponent},

    // otherwise redirect to home
    { path: '**', redirectTo: '' }
];

export const routing = RouterModule.forRoot(appRoutes);
