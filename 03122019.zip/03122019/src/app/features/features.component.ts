import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { User } from '../_models';

@Component({
  selector: 'app-features',
  templateUrl: './features.component.html',
  styleUrls: ['./features.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class FeaturesComponent implements OnInit {

  private _opened: boolean = true;
  currentUser: User;

  constructor() { }

  ngOnInit() {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
  }

  private _toggleOpened(event:any): void {
    event.preventDefault();
    this._opened = !this._opened;
  }

}
