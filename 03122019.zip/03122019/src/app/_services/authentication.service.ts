﻿import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';

import { environment } from '../../environments/environment';

@Injectable()
export class AuthenticationService {
  constructor(private http: HttpClient) { }

  login(username: string, password: string, forcedLogin: boolean) {
    console.log(forcedLogin)
    return this.http.post<any>(`${environment.apiUrl}/login`, { email: username, password: password, forcedLogin: forcedLogin })
      .pipe(map(user => {
        // login successful if there's a jwt token in the response
        console.log('Temp')
        console.log(user)
        user.token = user.auth_token
        if (user && user.token) {
          // store user details and jwt token in local storage to keep user logged in between page refreshes
          localStorage.setItem('currentUser', JSON.stringify(user));
        }

        return user;
      }));
  }

  logout() {

    // return this.http.post(`${environment.apiUrl}/logout`,{});
    console.log('Inside log out method');
    let currentUser = JSON.parse(localStorage.getItem('currentUser'));
    console.log(currentUser)
    console.log('Test')
    // this.http.post(`${environment.apiUrl}/logout`,{}).subscribe(
    //     (val) => {
    //         console.log("POST call successful value returned in body",
    //                     val);
    //         localStorage.removeItem('currentUser');
    //         return true
    //     },
    //     response => {
    //         console.log("POST call in error", response);
    //     },
    //     () => {
    //         console.log("The POST observable is now completed.");
    //     });
      localStorage.removeItem('currentUser');

  }
}

