import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

const endpoint = 'http://localhost:5000';

@Injectable()
export class UndialService {

  constructor(private http: HttpClient) { }


  getAllTargetTables(userId, taskId) {
    return this.http.get(`${endpoint}/user/${userId}/lineage/${taskId}/target_tables`)
  }

  processScripts() {
    return this.http.get(`${endpoint}/process`)
  }

  initUndial() {
    return this.http.get(`${endpoint}/init`)
  }

  getGraphData(userId, taskId, tableName) {
    return this.http.get(`${endpoint}/user/${userId}/graph/${taskId}/${tableName}`)
  }

  getTableMapping(userId, taskId) {
    return this.http.get(`${endpoint}/user/${userId}/lineage/${taskId}/table`)
  }

  getColumnMapping(userId, taskId) {
    return this.http.get(`${endpoint}/user/${userId}/lineage/${taskId}/column`)
  }

  downloadTableMapping() {
    return this.http.get(`${endpoint}/downloadTableMapping`)
  }

  getTaskSummary(userId, taskId) {
    return this.http.get(`${endpoint}/user/${userId}/summary/${taskId}`)
  }


}
