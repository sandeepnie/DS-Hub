﻿import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from "@angular/router";
import { first } from 'rxjs/operators';

import * as d3 from 'd3';
import {AgWordCloudData} from 'angular4-word-cloud';


import { User, Task } from '../_models';
import { UserService } from '../_services';
import { UndialService } from '../_services';
import { NgxSpinnerService } from 'ngx-spinner';
import { AuthenticationService } from '../_services';
import { ChangeDetectorRef } from '@angular/core';

let SpeechRecognition : any = (window.webkitSpeechRecognition) || window.SpeechRecognition;
// const synth = window.speechSynthesis; 
const recognition = new SpeechRecognition();


@Component({
templateUrl: 'home.component.html', styleUrls: ['./home.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class HomeComponent implements OnInit {
  transcription: any;
  predictions:any;
  currentUser: User;
  users: User[] = [];
  loading: boolean = false;
  private _opened: boolean = true;
  tasks: Task[] = [];

  wordData: Array<AgWordCloudData> = [
    {size: 100, text: 'Itching', color:'Red'},
    {size: 301, text: 'Skin Rash', color:'#22BAA0'},
    {size: 123, text: 'Shivering', color:'#22BAA0'},
    {size: 321, text: 'Joint Pain', color:'#22BAA0'},
    {size: 231, text: 'Stomach pain', color:'#22BAA0'},
    {size: 123, text: 'Fatigue', color:'#22BAA0'},
    {size: 346, text: 'Fever', color:'#22BAA0'},
    {size: 107, text: 'Dehydration', color:'#22BAA0'},
    {size: 436, text: 'Diarrhoea', color:'#22BAA0'},
    {size: 731, text: 'Chest Pain', color:'#22BAA0'},
    {size: 80, text: 'Blackheads', color:'#22BAA0'},
    {size: 96, text: 'Blister', color:'#22BAA0'},
    {size: 531, text: 'Depression', color:'#22BAA0'},
    {size: 109, text: 'Stiff Neck', color:'#22BAA0'},
    {size: 972, text: 'Cramps', color:'#FF6B8D'},
    {size: 213, text: 'Runny Nose', color:'#22BAA0'},
    {size: 294, text: 'Mild Fever', color:'#22BAA0'},
    {size: 472, text: 'Indigestion', color:'#22BAA0'},
    {size: 297, text: 'Wieght Loss', color:'#22BAA0'},
    {size: 456, text: 'Wieght Gain', color:'#22BAA0'},
    {size: 123, text: 'Ulcers', color:'#22BAA0'},
    {size: 376, text: 'Anxiety', color:'#22BAA0'},
    {size: 93, text: 'Breathlessness', color:'#22BAA0'},
    {size: 123, text: 'Headache', color:'#22BAA0'},
];
// Word Cloud Options
  options = {
      settings: {
          minFontSize: 20,
          maxFontSize: 100,
          fontFace: 'Arial',
          fontWeight: 'bolder',
      },
      margin: {
          top: 1,
          right: 1,
          bottom: 1,
          left: 1
      },
      labels: false // false to hide hover labels
  };

  private _toggleOpened(): void {
    this._opened = !this._opened;
  }
 
  startListening(){
    recognition.interimResults = true
    recognition.start();
    
    recognition.onresult = (event) => {
      const speechToText = event.results[0][0].transcript;      
      this.transcription = speechToText + ".";
      this.ref.detectChanges()

      if (event.results[0]["isFinal"] == true) {
        this.spinner.show();
        this.ref.detectChanges();
        this.userService.getDisease(this.transcription).subscribe(data=>{
          console.log(data["prediction"]);
          this.predictions = data["prediction"];
          this.spinner.hide();
          this.ref.detectChanges();
          
        });
      }
    }

    
  }

  checkTranscription(){
    if(this.transcription == 'Click on the button and describe your symptoms.') {
      return false;
    }
    return true;
  }

  checkPredictions(){
    if (this.predictions == '') {
      return false;
    }
    return true;
  }



  afuConfig = {
    multiple: true,
    formatsAllowed: ".sql, .txt, .zip",
    maxSize: "10",
    uploadAPI: {
      url: "http://localhost:5000/file/upload"
    },
    theme: "dragNDrop",
    hideProgressBar: false,
    hideResetBtn: true,
    hideSelectBtn: false,
    uploadBtnText: 'Upload and Process'
  };

  constructor(private userService: UserService, private undialService: UndialService,
    private router: Router, private spinner: NgxSpinnerService,
    private authenticationService: AuthenticationService, private ref: ChangeDetectorRef) {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
  }

  ngOnInit() {
    console.log('Init method called');
    this.transcription = "Click on the button and describe your symptoms.";
    this.predictions = '';
    // this.initUndial();
    // this.loadAllUsers();
    // this.loadTasks();
  }

  DocUpload(event){
    console.log('Inside docupload');
    console.log(event)
    if(event.status == 200) {
      console.log('200 response from API');
      // Reload task list
      this.loadTasks();
    }
  }

  private initUndial() {
    console.log('Init Undial');
    this.undialService.initUndial().subscribe(data => {
      console.log('Initialization completed');
    });
  }

  private loadAllUsers() {
    this.userService.getAll().pipe(first()).subscribe(users => {
      this.users = users;
    });
  }

  private loadTasks() {
    this.spinner.show()
    this.userService.getAllTask(this.currentUser.id).pipe(first()).subscribe(tasks => {
      this.tasks = tasks;
      console.log('Inside load task')
      console.log(tasks)
      this.spinner.hide();
    });
  }

  onProcess() {
    console.log('Clicked on process');
    this.loading = true;
    this.spinner.show();
    this.undialService.processScripts().subscribe(data => {
      console.log('Processing complete');
      this.loading = false;
      this.spinner.hide();
      this.router.navigate(['/output']);
    });
  }

  checkExistingTask(){
    if(this.tasks && this.tasks.length >0){
      return true
    }
    else{
      return false
    }
  }

  onTaskRowClick(taskId:any, taskStatus:string){
    console.log('click');
    console.log(taskId);
    console.log(taskStatus);
    if(taskStatus == 'Complete'){
      this.router.navigate(['/output'],{ queryParams: { task:taskId}});
    }
  }

  logout(){
    localStorage.removeItem('currentUser');
    this.router.navigate(['/login']);
    // this.authenticationService.logout().subscribe(data => {
    //   if (data.status == 'success'){
    //     localStorage.removeItem('currentUser');
    //     this.router.navigate(['/login']);
    //   }
    // });
  }
}
